<?php
require 'includes/_header.php';
include "includes/config.php";
require 'includes/head.php';
?>

<body style="background-color:#fff;">

<img src="img/err.png" style="  margin: 98px 369px 18px;"></img>
<h2 style="text-align: center;margin-left: 62px;"> Code d'erreur :404 </h2>
<p style="text-align: center;
    font-weight: bold;
    font-size: 22px;
    color: #0000006e;
    margin-left: 54px;
    font-family: sans-serif;
    margin-bottom: -23px;"> la page que vous recherchez </p>
<p style="text-align: center;
    font-weight: bold;
    font-size: 22px;
    color: #0000006e;
    margin-left: 54px;
    font-family: sans-serif;
    ">semble introuvable </p>


<button style="margin: -54px 24px 18px 630px;padding: 10px;background-color: hsl(220deg 100% 42%);border: none;">
    <a href="index.php" style="text-decoration: none;color: #fff;">Retour à la page D'accueil<a>
</button>

</body>
</html>