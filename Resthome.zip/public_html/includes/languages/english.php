<?php
    $lang=array(
        "bienvenue"=>"welcome",
        "Delicieuse"=>"Delicious",
        "order"=>"order now",
        "indexTitle"=>"Food Place",
        "indexParagraphe"=>"Speed, control and experience for your convenience and to <br> provide you with the best food is our duty.",
        "navCart"=>"to the carte",
        "reservation"=>"booking",
        "commande"=>"ordered",
        "Viande"=>"Meat",
        "Poisson"=>"Fish",
        "Boissons"=>"Drinks",
        "Fruits"=>"Fruits",
        "Ajouter"=>"add to cart",
        "dh"=>"DH",
        "Reserve maintenant"=>" Book now",
        "add" => "add to cart",
        "cmdd" => "Order from the site and get 10% off",
        )

?>