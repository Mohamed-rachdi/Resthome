<?php
    $lang=array(
        "bienvenue"=>"bienvenue",
        "Delicieuse"=>"Délicieuse",
        "order"=>"Commandez",
        "indexTitle"=>"Place Des Aliments",
        "indexParagraphe"=>"Rapidité, maîtrise et expérience pour votre commodité et<br>vous fournir la meilleure nourriture est notre devoir",
        "navCart"=>"à la carte",
        "reservation"=>"réservation",
        "commande"=>"commande",
        "Viande"=>"Viande",
        "Poisson"=>"Poisson",
        "Boissons"=>"Boissons",
        "Fruits"=>"Fruits",
        "Ajouter"=>"Ajouter",
        "dh"=>"DH",
        "Reserve maintenant"=>" Reserve maintenant",
        "add" => "Ajouter ",
        "cmdd" => "commandez sur le site et obtenez un rabais de 10 %",
        )

?>