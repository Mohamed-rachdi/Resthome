<?php

    $lang=array(
        "bienvenue"=>"مرحبا بكم",
        "Delicieuse"=>"اروع الاطباق",
        "order"=>"اطلب الان",
        "indexTitle"=>"مكان الطعام        ",
        "indexParagraphe"=>"السرعة والتحكم والخبرة لراحتك و
من واجبنا تزويدك بأفضل غذاء ",
        "navCart"=>"لوحة الاطباق",
        "reservation"=>"حجز مقعد",
        "commande"=>"طلب وجبة",
        "Viande"=>"لحم",
        "Poisson"=>"سمك",
        "Boissons"=>"مشروبات",
        "Fruits"=>"فواكه",
        "Ajouter"=>"أضف إلى السلة",
        "dh"=>"درهم",
        "Reserve maintenant"=>" احجز الآن",
        "add" => "أضف إلى السلة",
        "cmdd" => "اطلب من الموقع واحصل على خصم 10٪",
        
    )

?>