<?php
    $lang=array(
        "bienvenue"=>"欢迎来我们家",
        "Delicieuse"=>"非常美味",
        "order"=>"现在下单",
        "indexTitle"=>"美食广场",
        "indexParagraphe"=>"速度、控制和体验，为您提供方便并为您提供最好的食物是我们的职责",
        "navCart"=>"到购物车",
        "reservation"=>"预订",
        "commande"=>"订购",
        "Viande"=>"肉",
        "Poisson"=>"鱼",
        "Boissons"=>"饮料",
        "Fruits"=>"水果",
        "Ajouter"=>"添加到购物车",
        "dh"=>"迪拉姆",
        "Reserve maintenant"=>"现在预订",
        "add" => "添加到购物车",
        "cmdd" => "从网站订购并获得 10% 的折扣",
        )

?>