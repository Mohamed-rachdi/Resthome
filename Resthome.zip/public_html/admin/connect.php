<?php 
$connection = new PDO('mysql:host=localhost;dbname=id17068973_risthom','id17068973_cmnd','38lQLu(?~6K*kSx5');
?>