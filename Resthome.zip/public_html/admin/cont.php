<?php
$databaseHost = 'localhost';   //your db host 
$databaseName = 'id17068973_risthom';  //your db name 
$databaseUsername = 'id17068973_cmnd';    //your db username 
$databasePassword = '38lQLu(?~6K*kSx5';//   db password 

$mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName); 
 
 
$sql = "SELECT * FROM commandes";
 
$mysqliStatus = $mysqli->query($sql);
 
$rows_count_value = mysqli_num_rows($mysqliStatus);

$mysqli->close();

?>
