<?php
// Informations d'identification
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'id17068973_cmnd');
define('DB_PASSWORD', '38lQLu(?~6K*kSx5');
define('DB_NAME', 'id17068973_risthom');
 
// Connexion à la base de données MySQL 
$conn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
 
// Vérifier la connexion
if($conn === false){
    die("ERREUR : Impossible de se connecter. " . mysqli_connect_error());
}
?>