<!DOCTYPE html>


<html>
<head>

    <meta charset="UTF-8">
    <meta name="description" content="Menu Restaurant">
    <meta name="keywords" content="Menu, Restaurant, food">
    <meta name="author" content="Rachdi">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/admin.css">
    <link rel="stylesheet" href="css/responsive.css">
    <link rel="stylesheet" href="css/all.css">


</head>